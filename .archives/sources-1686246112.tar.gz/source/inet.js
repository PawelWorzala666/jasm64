

    //::app:cmd




    function Main(){


        printf('START %s',EOL)


        invoke 
        INETCC()


        printf('error %s',EOL)

    }


    .data

    urlradio       db "http\\:\\/\\/direct.franceculture.fr\\/live\\/franceculture\\-midfi\\.mp3",0
    Hinternet       dd 0
    dwContext       dd 0
    Hrequest      dd 0
    Hconnect      dd 0
    Hurl         dd 0
    szStatusCode    dB 400 dup (0)

    NullTexte db "a",0



    .data?

    dwIndex dq ?
    dwBufLength dq ?
    
    .code



    function INETCC(){
/*
;----------------------------------------------------------------------------
;################################################################
InitInternet PROC*/
      /*Local phrase[MAX_PATH]:BYTE,dwIndex:DWORD,dwBufLength
      Local  retour:DWORD
         mov retour,0
      mov dwContext,0   ;mode synchrone
         
      ;HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Internet Settings
      ;https://docs.microsoft.com/en-us/windows/win32/wininet/enabling-internet-functionality   */   
      invoke InternetOpen, "EditMasm",INTERNET_OPEN_TYPE_PRECONFIG,NULL,NULL,INTERNET_FLAG_ASYNC ;;NULL
      mov Hinternet,rax
      /*.if rax == NULL
         ;invoke RetrouveMessageErreur, "InternetOpen Failed"
         jmp FindeInitInternet
      .endif
      ;invoke InternetOpenUrl,Hinternet,addr urlradio,NULL,NULL,INTERNET_FLAG_RAW_DATA,dwContext
      ;invoke InternetQueryDataAvailable
      ;mov Hurl,rax
      ;.if rax == NULL
      ;     invoke  InternetCloseHandle,Hinternet
      ;   invoke RetrouveMessageErreur, "InternetOpenUrl Failed"
      ;   jmp FindeInitInternet                  
      ;.endif*/
      
      printf('START 1 %s',EOL)


      //;TXT("http://direct.franceculture.fr")
      invoke InternetConnect,Hinternet, addr urlradio,INTERNET_DEFAULT_HTTP_PORT,\
                  NULL,NULL,INTERNET_SERVICE_HTTP,NULL,NULL ;INTERNET_FLAG_EXISTING_CONNECT,dwContext
      mov Hconnect,rax
      /*.if rax == NULL
           invoke  InternetCloseHandle,Hinternet
         ;invoke RetrouveMessageErreur, "HttpOpenRequest Failed"
         jmp FindeInitInternet         
      .endif  */    

      printf('START 2 %s',EOL)
      
      //;/"http://direct.franceculture.fr/live/franceculture-midfi.mp3"
      //;HttpOpenRequest( hHttpSession, "GET", "", NULL,      "", NULL, 0, 0
      invoke  HttpOpenRequest,Hconnect, "GET",addr NullTexte,NULL,addr NullTexte,NULL,NULL,addr dwContext
      mov Hrequest,rax
      /*.if rax == NULL
         invoke  InternetCloseHandle,Hconnect
         invoke  InternetCloseHandle,Hinternet
         ;invoke RetrouveMessageErreur, "HttpOpenRequest Failed"
         jmp FindeInitInternet         
      .endif
      ;invoke o_printcrlf,addr szStatusCode*/
      printf('START 33 %s %s',addr NullTexte,EOL)

      printf('START 3 %s',EOL)
             
      invoke HttpSendRequest,Hrequest,addr NullTexte,NULL,addr NullTexte,2

      printf('START 4 %s %s',addr NullTexte,EOL)
      /*.if rax == NULL
         invoke  InternetCloseHandle,Hrequest
         invoke  InternetCloseHandle,Hconnect
         invoke  InternetCloseHandle,Hinternet
         ;invoke RetrouveMessageErreur, "HttpOpenRequest Failed"        
         jmp FindeInitInternet
      .endif*/
      //;------------------------- Interrogation --------------------------------------------
          mov     dwIndex,0
          mov     dwBufLength,sizeof szStatusCode      
          invoke  HttpQueryInfo,Hrequest,HTTP_QUERY_ACCEPT,addr szStatusCode,addr dwBufLength,addr dwIndex
     // /*.if rax == FALSE
       //  ;invoke RetrouveMessageErreur, "HttpQueryInfo Failed"
      ///.else
         //invoke MessageBox,NULL,addr szStatusCode,"HttpQueryInfo HTTP_QUERY_ACCEPT",MB_OK               
      //.endif*/
      printf('START 4 %i %s',dword ptr szStatusCode,EOL)
      
      //;After opening a request with HttpOpenRequest and sending it to the server with HttpSendRequest, the
      //; application can use the InternetReadFile, InternetQueryDataAvailable, and InternetSetFilePointer functions
      //; to download the resource from the HTTP server.
           // mov retour,1
/*
 FindeInitInternet:
         mov rax,retour
         ret
InitInternet endp
*/

    }