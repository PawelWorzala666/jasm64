
    //:app:cmd


    //hfile1 dq ?
    _size1 dq ?

    class cFILE{
        constructor(){
           this.afile1 = 0
           this.asize1 = 0
        }
        ReadFile(file1, buffor1){

            hfile1 = CreateFile(file1, GENERIC_READ or GENERIC_WRITE,0,0,OPEN_EXISTING,FILE_ATTRIBUTE_ARCHIVE, 0)
                //conout('CreateFile...',str$\\(\\hfile1),EOL)
                
                _size1 = GetFileSize(hfile1, 0)

                //conout('GetFileSize...',str$\\(\\_size1),EOL)
                printf('_size1... %i %s',_size1,EOL)
                //add _size1,1
                //buffor1 = GlobalAlloc(GMEM_ZEROINIT or GMEM_FIXED,_size1)
                buffor1 = alloc(_size1)

                //conout('alloc...',EOL)
                
                ReadFile(hfile1, buffor1, _size1, 0, 0)

                //printf('buffor1... %s %s',buffor1,EOL)

                CloseHandle(hfile1)
        }
    }

    var file = new cFILE()

