

/*
    class cFONT{
        constructor(){
            ID = 0
        }
*/

function DrawLetter(number){

            mov numLtr1,number

                
            lea rax,widthsFnt
            //mov rcx,number
            imul rcx,8
            mov rax,[rax\\+\\rcx]
            mov wiid,rax
            //wiid = widthsFnt[number]
            printf('wiid %f %s',wiid,lf)

            mat4.identity(matrix1)
            mat4.translate(matrix1,matrix1,translate1)
            mat4.scale(matrix1,matrix1,scale1)




            //fild qword ptr wiid
            //fdiv qword ptr fnMaxWidth
            //fstp qword ptr fntOffsetX
            Math_podziel(wiid,fnMaxWidth,fntOffsetX)

            printf('%f %s',fntOffsetX,lf)

            Math_pomnoz(fntOffsetX,fntDefWidth,newfntOffsetX)

            printf('ff %f %s',newfntOffsetX,lf)
            
            //Math_pomnoz(newfntOffsetX,fntDefFactrrX,fntOffsetX22)

            Math_pomnoz(fntDefFactrrX,newfntOffsetX,newfntOffsetX)

            printf('%f %s',newfntOffsetX,lf)



            RenderLetter(numLtr1)
            

            Math_dodaj(translate1[0],newfntOffsetX,translate1[0])

            printf('tt %f %s',translate1[0],lf)

            //translate1[0] = fntOffsetX22




        }

function RenderLetter(number){

                mov rax\\,n\\umber
                mov qword ptr tmpNumber11,rax

                cSHADER_SetUniform1i(shader1, 'fontIndex', tmpNumber11)

                cSHADER_SetUniform1d(shader1, 'fontWidth', wiid)
            
                cSHADER_SetUniformMatrix(shader1, 'projection', projection)
                cSHADER_SetUniformMatrix(shader1, 'camera', camera)
                cSHADER_SetUniformMatrix(shader1, 'model', matrix1)



                

                cMODEL_ModelRender(pModel)

            }
            
function PrintOutAllText(text11){
            
            mov rdi, 0
            mov RDIptr,rdi

            .loop11:
                MOV RCX, offset text11
                mov rax,RDIptr
                mov rdi,rax
                ADD RCX, rdi
            
                MOV DL, byte ptr [rcx]
                MOVZX RBX, DL

                mov rax,0
                cmp RBX,rax
                je .endo11

                mov rax,rbx
                //push rcx
                //PrintLetter(rax)
                //rcall callback11, rax
                //printf('letter %i %s',rax,lf)
                mov rcx,rbx
                DrawLetter(rax)
                //pop rcx

                //mov rdi,1
                add RDIptr,1

                jmp .loop11
            .endo11:

        }

    

        /*
        //::proc
        function PrintLetter(char11){
            //printf('char %i %s',char11,EOL)
            DrawLetter(char11)
        }
        //::endproc

    */