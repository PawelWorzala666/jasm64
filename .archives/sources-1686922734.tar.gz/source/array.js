
    //::app:cmd



    /*class cARRAY{

        constructor(){
            //this.arr_ay = 0
            this.as_ize = 0
            this.to_tal = 0
        }*/

        /*init(){
            parrsize = 0
            parrtotal = 0
        }*/

        //alloc(){
            /*mov rbx, parrtotal
            mov rcx, parrsize
            add rcx, 128*8
            cmp rbx, rcx
            jng .end1
            mov rcx, 0
            cmp rbx, rcx
            jne .end1
            mov rax, alloc(1024*8)
            mov this.array, rax
                mov rax,1024*8
                add parrtotal, rax
            .end1:*/
            //invoke realloc, parrsize, 1024*8
            //mov parrsize, alloc(1024*8)
       // }
        /*alloc2(){
            mov rbx, parrtotal
            mov rcx, parrsize
            add rcx, 128*8
            cmp rbx, rcx
            jng .end2
            mov rcx, 0
            cmp rbx, rcx
            jne .end2
            mov rax, alloc(1024*8)
            mov this.array, rax
                mov rax,1024*8
                add parrtotal, rax
            .end2:
        }*/

     /*function parray_pushOnId(id, value){
            //cARRAY_alloc1(this)

            //add parrsize, 8
            mov rbx, id

            mov rcx, parray11//this.array
            mov rax, rbx
            add rax, rcx
            
            mov rax, qword ptr value
            //mov rcx\\+rbx, rax
            
            //parrsize++
        }*/
        
        function parray_push(value){
            //cARRAY_alloc2(this)

            //mov rbx, parrsize
            //imul rbx, 8
            add parrsize, 8
            mov rbx, parrsize
            //printf('val 0 rbx: %i %s', rbx, EOL)
            
            //mov rdi, rbx
            
            lea rcx, parray11//this.array
            //mov rax, rbx
            //lea rdx, [rcx\\+rbx]
            //add qword ptr rcx\\+rbx, rbx

            lea rax,value
            //printf('XXX 0: %s %s', rax, EOL)
            mov [rcx\\+rbx], rax

            //mov rcx\\+rbx, rax    
            //lea rcx, this.array
            mov rax,[rcx\\+rbx]
            printf('XXX 0: %s %s', rax, EOL)
            
            //parrsize++
        }
        
    function parray_get(index){
            mov rcx, index
            imul rcx, 8
            //add rbx, 8
            //printf('val 0 rbx: %i %s', rbx, EOL)

            lea rdx, parray11//this.array
            add rdx,rcx
            //printf('val 0 rcx: %f %s', rcx, EOL)
            mov rax, \\[rdx]
            //printf('val 0 rax: %f %s', rax, EOL)
            //lea rax, [rdi\\+rbx]
            //printf('val 0 rax: %f %s', rax, EOL)

            //printf('val AA 0: %f %s', this.array\\[\\8], EOL)
            //mov rax, rdx
            //mov rbx, this.array\\+rbx
        }

        /*getIndexByName(value){
            this.pindex = 0
            while(this.pindex<16){
                virtual mov rbx, [this.array+this.pindex*8]
                compare(value, rbx)
                virtual this.comp = rax
                mov rax, 1
                virtual this.compT = rax
                virtual if(this.comp==this.compT){
                    virtual mov rax, this.pindex
                    break
                }
                virtual this.pindex = this.pindex + 1
                mov rax, -1
            }
        }*/

   // }








    /*class cNamedArray{

        constructor(){
            this.names = new cArray()
            this.values = new cArray()
        }
        
        push(name,value){
            this.names.push(name)
            this.values.pushOnId(rax,value)
        }
        getById(name){
            this.values.get(name)
        }
        get(name){
            this.names.getIndexByName(name)
            this.values.get(rax)
        }
        pushOnId(id,value){
            this.names.pushOnId(id,id)
            this.values.pushOnId(id,value)
        }
    }*/



    

    
    
    function Main(){
        printf('started %s', lf)

        //parray.constructor()

        //parray.alloc()
        printf('started %i %s', 245,lf)

        lea rax, ptext1a
        printf('text2 %s %s',rax,lf)

        parray.push(ptext1a)
        //printf('text1 %i %s',rdi, EOL)

        parray.get(1)
        printf('val 0: %s %s', rax, EOL)
        //parray.push(text2)
        //printf('text2 %s', EOL)

        //parray.get(0)'''
        //printf('val 0: %s %s', rax, EOL)end

        //parray.get(1)
        //printf('val 1: %s %s', rax, EOL)

        /*narray.push(v1,text1)
        //invoke(printf,'v1: %i %s', rax, EOL)
        narray.get(v1)
        invoke(printf,'v1: %s %s', rax, EOL)*/

        
        //invoke(printf,'pstack: %i %s', rax, EOL)
        //pstack.push(text2)
        //invoke(printf,'pstack: %s %s', 'rax', EOL)
        //pstack.get()
        //invoke(printf,'pstack: %s %s', 'rax', EOL)
    
        printf('end %s', lf)
    }
    



     //var narray = new cNamedArray()
    //var parray = new cARRAY()
    //var pstack = new cStack()

    //.data
    parray11 d\\q\\(10\\24) dup (0)

    var parrsize = 0
    var parrtotal = 0

    //var val1 = 0
    //var num1 = 32.444
    //var num2 = 443.444
    //var text12 = 'hello'
    var ptext1a = 'hello world'
    //var text2 = 'test'

    //var v1 = 'v1'
    //var v2 = 'v2'
    //var v3 = 'v3'
    //var v4 = 'v4'
   
    //var zeroPtr = 0
    