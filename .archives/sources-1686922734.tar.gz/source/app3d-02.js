
    //::app:gl

    import 'opengl/mat4s.js'
 
    import 'utils/utils.js'
    import 'opengl/uniform.js'
    import 'utils/file.js'
    import 'opengl/texture.js'
    import 'opengl/shader.js'

    import 'models/model-02.js'
    import 'opengl/font.js'



    .data
    var pModel = new cMODEL()

    var shader1 = new cSHADER()



    /*.data
        var fovy112 = 45.0
        var aspect112 = 1.0
        var near112 = 0.1
        var far112 = 100.0*/
    
    

    .data?
        matrix1 dq 16 dup(0.0)
        matrix2 dq 16 dup(0.0)
        /*projection1 dq 16 dup(0.0)
        camera11 dq 16 dup(0.0)*/

    /*.data

        var scale1 = [7.2,0.8,1.4]

        //var scale2

        var axisY = [0.0,1.0,0.0]
        //var rad1112 = 34.44

        //var angleY22 = 34.66
        //var radCC111 = 0.0

        var eye22 = [0.10,0.0310,0.80]
        var center22 = [0.10,0.30,\\-0.80]
        var up22 = [0.0,1.0,0.0]

        var projN1 = \\-2\\.0202020202020203
        var projN2 = \\-1\\.0*/

        //tarnslate11 \\d\\q 0.0,0.0,\\-1\\.500090086



    .data
    textTest1 d\\b 'Hello World',0


    
.code



    function SystemInit(){

        invoke FreeImage_Initialise

        InitGLFunctions()





        

        shader1.CreateShader('shaders\font.vert','shaders\font.frag')

        
        
        
        pModel.CreateGeometry()





        


        gl.Enable(gl.DEPTH_TEST)
        gl.DepthFunc(gl.LEQUAL)
        gl.Enable(gl.TEXTURE_2D)

        gl.Enable(gl.BLEND);
        gl.BlendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

    
        //TestThread()


        movd	xmm3,coloralpha
        movd	xmm2,colorcomathree
        movd	xmm1,colorcmmasn
        movd	xmm0,colorcmmasn
        invoke glClearColor//(float dword 0.3, dword 0.3, dword 0.3, dword 1.0)






        //matrix1 = mat4.create()
        mat4.identity(matrix1)
        PrintMatrix('mat4.identity',matrix1)

        /*mat4.identity(camera11)
        mat4.identity(matrix2)
        mat4.translate(camera11,matrix2,tarnslate11)
        PrintMatrix('mat4.translate',camera11)*/

        //Math.Deg2Rad(fovy33,radCC111)
        /*mat4.perspectiveNO(projection1, fovy112, aspect112, near112, far112)
        projection1[11] = projN2
        projection1[14] = projN1
        PrintMatrix('mat4.perspectiveNO',projection1)*/


    }



    var numLtr1 = 0
   
    var RDIptr = 0
    



    function SystemRender(){


        gl.Clear(gl.COLOR_BUFFER_BIT or gl.DEPTH_BUFFER_BIT)







        frameID++
    
        shader1.Use()
    
        shader1.SetUniform1i('frame', frameID)






        translate1[0] = troneptr1X
        translate1[1] = troneptr1Y

        /*DrawLetter(65)
        DrawLetter(66)
        DrawLetter(67)
        DrawLetter(68)
        DrawLetter(69)*/

        PrintOutAllText(textTest1)

        

    }


    function SystemDestroy(){

    
    }






    var frameID = 0
    
    .data
    widthsFnt d\\q 7.5,49.78125,0.0,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,16.0,16.0,16.0,16.0,
        d\\q 16.0,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,
        d\\q 49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,16.0,21.3125,26.125,32.0,32.0,53.3125,49.78125,
        d\\q 11.53125,21.3125,21.3125,32.0,36.09375,16.0,21.3125,16.0,17.78125,32.0,32.0,32.0,32.0,
        d\\q 32.0,32.0,32.0,32.0,32.0,32.0,17.78125,17.78125,36.09375,36.09375,36.09375,28.40625,58.9375,
        d\\q 42.6875,42.6875,42.6875,42.6875,39.09375,35.59375,42.6875,42.6875,21.3125,24.90625,46.21875,39.09375,56.90625,
        d\\q 46.21875,46.21875,35.59375,46.21875,42.6875,35.59375,39.09375,46.21875,46.21875,60.40625,46.21875,46.21875,39.09375,
        d\\q 21.3125,17.78125,21.3125,30.03125,32.0,21.3125,28.40625,32.0,28.40625,32.0,28.40625,21.3125,32.0,
        d\\q 32.0,17.78125,17.78125,32.0,17.78125,49.78125,32.0,32.0,32.0,32.0,21.3125,24.90625,17.78125,
        d\\q 32.0,32.0,46.21875,32.0,32.0,28.40625,30.71875,12.8125,30.71875,34.625,32.0,49.78125,49.78125,
        d\\q 49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,
        d\\q 49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,49.78125,
        d\\q 49.78125,49.78125,49.78125,49.78125,16.0,21.3125,32.0,32.0,32.0,32.0,12.8125,32.0,21.3125,
        d\\q 48.625,17.65625,32.0,36.09375,0.0,48.625,32.0,25.59375,35.125,19.1875,19.1875,21.3125,36.875,
        d\\q 29.0,21.3125,21.3125,19.1875,19.84375,32.0,48.0,48.0,48.0,28.40625,46.21875,46.21875,46.21875,
        d\\q 46.21875,46.21875,46.21875,56.90625,42.6875,39.09375,39.09375,39.09375,39.09375,21.3125,21.3125,21.3125,21.3125,
        d\\q 46.21875,46.21875,46.21875,46.21875,46.21875,46.21875,46.21875,36.09375,46.21875,46.21875,46.21875,46.21875,46.21875,
        d\\q 46.21875,35.59375,32.0,28.40625,28.40625,28.40625,28.40625,28.40625,28.40625,42.6875,28.40625,28.40625,28.40625,
        d\\q 28.40625,28.40625,17.78125,17.78125,17.78125,17.78125,32.0,32.0,32.0,32.0,32.0,32.0,32.0,
        d\\q 35.125,32.0,32.0,32.0,32.0,32.0,32.0,32.0,32.0



        

    colorcomathree dd 0.3
    colorcmmasevben dd 0.7
    colorcmmasn dd 0.25
    coloralpha dd 1.0


    var projection = [1.3737387097273113,0.0,0.0,0.0,0.0,1.3737387097273113,0.0,0.0,0.0,0.0,-1.02020202020202,-1.0,0.0,0.0,-2.0202020202020203,0.0]
    var camera = [1.0,0.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,-1.5300090086,1.0]
    var model = [1.0,0.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,0.0,1.0]

    var scale1 = [0.1,0.1,0.1]
    var translate1 = [-\\1.0,1.0,0.0]




    .data
        var troneptr1X = -\\1.0
        var troneptr1Y = 1.0
        var fntOffsetX = 0.0
        var fntDefWidth = 0.1
        var fnMaxWidth = 64.0
        var newfntOffsetX = 0.0
        var fntOffsetX22 = 0.0
        var fntDefFactrrX = 1.73


        .data
        var wiid = 0
    



.data
    var tmpNumber11 = 0

    
