
    //::app:gl

 
    import 'uniform.js'
    import 'file.js'
    import 'texture.js'
    import 'shader.js'
    import 'model.js'




    .data
    var pModel = new cMODEL()

    var shader1 = new cSHADER()


    function SystemInit(){

        invoke FreeImage_Initialise

        InitGLFunctions()





        

        shader1.CreateShader('twoo.vert','twoo.frag')

        
        
        
        pModel.CreateGeometry()


        


        gl.Enable(gl.DEPTH_TEST)
        gl.DepthFunc(gl.LEQUAL)
        gl.Enable(gl.TEXTURE_2D)


    
        




    }






    function SystemRender(){


        gl.Clear(gl.COLOR_BUFFER_BIT or gl.DEPTH_BUFFER_BIT)

        

        pModel.ModelRender()


    }


