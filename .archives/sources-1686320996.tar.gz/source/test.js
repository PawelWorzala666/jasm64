

    //::app:cmd


//alert('DUPA')



    function Main(){


        printf('START %s',EOL)

        dupaFunc()

        printf('BEGIN %s',EOL)


        printf('error %s',EOL)

    }


