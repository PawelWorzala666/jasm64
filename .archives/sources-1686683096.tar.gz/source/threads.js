

    //::app:cmd


//alert('DUPA')



function Main(){


    printf('START %s',EOL)

    
    //TestThread()
    mov hThread, rv(CreateThread,0,0, addr TestThread,addr arr,0,0)

    //invoke Sleep,10000


    printf('error %s',EOL)

}

.data?

    arr dq ?
    hThread dq ?

/*

.code
ThreadManager PROC

    LOCAL arr   :QWORD
    LOCAL hThread  :QWORD
    LOCAL hProcess :QWORD

    ///LOCAL rvar1 :QWORD          ; thread return value

    //LOCAL pvar1 :QWORD          ; its pointer

    //mov pvar1, ptr$(rvar1)      ; load address into pointer
    //mov rvar1, 0                ; set rvar1 to 0

    //;fn callthread,0,1,pvar1

    mov hThread, rv(CreateThread,0,0,ADDR TestThread,ADDR arr,0,0)

    



ThreadManager ENDP
*/

async function TestThread(){

    printf('THREAD %s',EOL)

}