
    //::app:cmd



    class cARRAY{

        constructor(){
            this.array = 0
            this.asize = 0
            this.total = 0
        }

        /*init(){
            this.asize = 0
            this.total = 0
        }*/

        alloc(){
            mov rbx, this.total
            mov rcx, this.asize
            add rcx, 128*8
            cmp rbx, rcx
            jng .end1
            mov rcx, 0
            cmp rbx, rcx
            jne .end1
            mov rax, alloc(1024*8)
            mov this.array, rax
                mov rax,1024*8
                add this.total, rax
            .end1:
        }
        /*alloc2(){
            mov rbx, this.total
            mov rcx, this.asize
            add rcx, 128*8
            cmp rbx, rcx
            jng .end2
            mov rcx, 0
            cmp rbx, rcx
            jne .end2
            mov rax, alloc(1024*8)
            mov this.array, rax
                mov rax,1024*8
                add this.total, rax
            .end2:
        }*/

        pushOnId(id, value){
            //cARRAY_alloc1(this)

            //add this.asize, 8
            mov rbx, id

            mov rcx, this.array
            mov rax, rbx
            add rax, rcx
            
            mov rax, qword ptr value
            //mov rcx\\+rbx, rax
            
            //this.asize++
        }
        
        push(value){
            //cARRAY_alloc2(this)

            //mov rbx, this.asize
            //imul rbx, 8
            add this.asize, 8
            mov rbx, this.asize
            //add rbx, 8
            
            mov rcx, this.array
            mov rax, rbx
            add rax, rcx
            //add qword ptr rcx\\+rbx, rbx

            mov rax, qword ptr value
            //mov rcx\\+rbx, rax    
            
            //this.asize++
        }
        
        get(index){
            mov rbx, index
            imul rbx, 8
            //add rbx, 8

            mov rcx, this.array
            mov rax, rbx
            add rax, rcx
            //add rax, rcx
            //mov rbx, this.array\\+rbx
        }

        /*getIndexByName(value){
            this.pindex = 0
            while(this.pindex<16){
                virtual mov rbx, [this.array+this.pindex*8]
                compare(value, rbx)
                virtual this.comp = rax
                mov rax, 1
                virtual this.compT = rax
                virtual if(this.comp==this.compT){
                    virtual mov rax, this.pindex
                    break
                }
                virtual this.pindex = this.pindex + 1
                mov rax, -1
            }
        }*/

    }








    /*class cNamedArray{

        constructor(){
            this.names = new cArray()
            this.values = new cArray()
        }
        
        push(name,value){
            this.names.push(name)
            this.values.pushOnId(rax,value)
        }
        getById(name){
            this.values.get(name)
        }
        get(name){
            this.names.getIndexByName(name)
            this.values.get(rax)
        }
        pushOnId(id,value){
            this.names.pushOnId(id,id)
            this.values.pushOnId(id,value)
        }
    }*/



    
 
    
    
    
    function Main(){
        printf('started %s', EOL)

        parray.alloc()

        parray.push(num1)
        printf('text1 %s', EOL)

        parray.get(0)
        printf('val 0: %f %s', rax, EOL)
        //parray.push(text2)
        //printf('text2 %s', EOL)

        //parray.get(0)
        //printf('val 0: %s %s', rax, EOL)

        //parray.get(1)
        //printf('val 1: %s %s', rax, EOL)

        /*narray.push(v1,text1)
        //invoke(printf,'v1: %i %s', rax, EOL)
        narray.get(v1)
        invoke(printf,'v1: %s %s', rax, EOL)*/

        
        //invoke(printf,'pstack: %i %s', rax, EOL)
        //pstack.push(text2)
        //invoke(printf,'pstack: %s %s', 'rax', EOL)
        //pstack.get()
        //invoke(printf,'pstack: %s %s', 'rax', EOL)
    
        printf('end %s', EOL)
    }
    
    
    //var narray = new cNamedArray()
    var parray = new cARRAY()
    //var pstack = new cStack()

    var val1 = 0
    var num1 = 32.444
    var num2 = 443.444
    var text12 = 'hello'
    var text1 = 'hello world'
    var text2 = 'test'

    var v1 = 'v1'
    var v2 = 'v2'
    var v3 = 'v3'
    var v4 = 'v4'
   
    var zeroPtr = 0


    //import 'string.js'

