
    //:app:cmd

//.daTA?
    //hfile1 dq ?
    //_size1 dq ?

    class cFILE{
        constructor(){
           this.handle = 0
           this.size = 0
        }
        ReadFile(file1, buffor1){

            this.handle = CreateFile(file1, GENERIC_READ or GENERIC_WRITE,0,0,OPEN_EXISTING,FILE_ATTRIBUTE_ARCHIVE, 0)
            //mov this.handle,rax
                //conout('CreateFile...',str$\\(\\hfile1),EOL)
                
                this.size = GetFileSize(this.handle, 0)
                //this.size = _size1

                //conout('GetFileSize...',str$\\(\\_size1),EOL)
                printf('this.size... %i %s',this.size,EOL)
                //add _size1,1
                //buffor1 = GlobalAlloc(GMEM_ZEROINIT or GMEM_FIXED,_size1)
                //mov rax, qword ptr this.fsize1

                buffor1 = alloc(this.size)

                //conout('alloc...',EOL)
                
                ReadFile(this.handle, buffor1, this.size, 0, 0)

                //printf('buffor1... %s %s',buffor1,EOL)

                CloseHandle(this.handle)
        }
        GetSize(){
            return this.size
        }
    }
.data
    var file = new cFILE()

