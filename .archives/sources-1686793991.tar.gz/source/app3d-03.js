
    //::app:gl

 
    import 'uniform.js'
    import 'file.js'
    import 'texture.js'
    import 'shader.js'
    import 'model-03.js'


    var pModel = new cMODEL()

    var shader1 = new cSHADER()


    function SystemInit(){

        invoke FreeImage_Initialise

        InitGLFunctions()


        SystemInitWorker()


        

        shader1.CreateShader('simple2.vert','simple2.frag')

        pModel.CreateGeometry()


        
		//LoadShader(ffrag,fvert)


        gl.Enable(gl.DEPTH_TEST)
        gl.DepthFunc(gl.LEQUAL)
        //gl.Enable(gl.TEXTURE_2D)





    }


    //::proc
    function SystemInitWorker(){

        printf('SystemInitWorker %s',EOL)

    }
    //::endproc

    





	//var ffrag = 'simple2.frag'
	//var fvert = 'simple2.vert'


    //ClearDepth1 dq 10

    function SystemRender(){


        //gl.Enable(gl.DEPTH_TEST)

        //gl.ClearDepth(1)

        movd	xmm3,consta10
        movd	xmm2,constd07
        movd	xmm1,constd07
        movd	xmm0,constd07
        invoke	glClearColor

        gl.Clear(gl.COLOR_BUFFER_BIT or gl.DEPTH_BUFFER_BIT)

        


        pModel.ModelRender()


    }


    function SystemDestroy(){

    
        //invoke FreeImage_DeInit

    }